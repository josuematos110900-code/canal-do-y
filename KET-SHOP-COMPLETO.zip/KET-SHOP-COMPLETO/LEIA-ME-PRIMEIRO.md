# KET SHOP — Pacote completo e actualizado

Plataforma de venda de diamantes e passes **Free Fire** em Kwanzas:
app Android (Java/XML, compatível com CodeAssist), painel administrativo Web e base de dados.

## O que está aqui

| Pasta | Conteúdo |
|---|---|
| `1-VERSAO-SUPABASE/` | App Android + painel admin + base de dados **Supabase** (SQL completo, regras de segurança, Storage) |
| `2-VERSAO-FIREBASE/` | A mesma plataforma com **Firebase** (Auth, Firestore, Storage, Security Rules) |
| `3-IMAGENS-DAS-TELAS/` | Imagens das 21 telas da app e capturas reais do painel |

**Escolha UMA das versões.** As duas fazem o mesmo; não as misture.
- **Supabase:** gratuito para começar; base de dados SQL; instalação com um único ficheiro (`INSTALL_ALL.sql`).
- **Firebase:** precisa do plano Blaze (pede cartão) para guardar os comprovativos.

## Começar (versão Supabase)
Siga **`1-VERSAO-SUPABASE/documentation/PASSO-A-PASSO-BASE-DE-DADOS.md`** (8 passos):
1. Criar um projecto Supabase **novo e vazio**.
2. SQL Editor → colar `supabase/INSTALL_ALL.sql` → Run.
3. Confirmar 13 produtos.
4. Criar a sua conta em Authentication → Users.
5. Tornar-se admin (comando SQL no guia).
6. Copiar URL + chave anon para `admin-web/js/config.js` e `SupabaseConfig.java`.
7. Publicar o painel e entrar.
8. Preencher os métodos de pagamento reais.

Depois: abrir `android-app` no CodeAssist → `documentation/CODEASSIST.md` e `BUILD_APK.md`.

## Começar (versão Firebase)
Siga **`2-VERSAO-FIREBASE/documentation/FIREBASE.md`**.

## Publicar na Google Play
Leia **`documentation/PLAY-STORE.md`** (em qualquer das versões): lista do que ainda falta,
incluindo a autorização da Garena para usar a marca Free Fire.

## Estado dos testes (honesto)
- **Base de dados Supabase:** testada em PostgreSQL 16 com simulação do Supabase (fluxo completo, segurança
  entre clientes, reexecução sem erros, bloqueio em projectos de outra aplicação).
- **Firebase:** regras (64/64), código Java da app (36/36) e painel no navegador (37/37) testados no emulador oficial.
- **App Android:** compila sem erros (recursos + Java, API 33).
- **Não testado:** compilação dentro do CodeAssist e execução num telemóvel real. As imagens das telas são
  reconstruções fiéis a partir do projecto, não capturas de um telemóvel.

## Configurações que tem de preencher
| Ficheiro | O quê |
|---|---|
| `SupabaseConfig.java` / `FirebaseConfig.java` | Chaves públicas do projecto |
| `admin-web/js/config.js` | Chaves públicas do projecto |
| Painel → Métodos de pagamento | IBAN, telefones, entidade/referência reais (nunca inventados) |
| Painel → Configurações | Contactos de suporte, textos legais revistos |
