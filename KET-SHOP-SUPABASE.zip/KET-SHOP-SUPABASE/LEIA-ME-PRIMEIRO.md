# KET SHOP — Pacote completo (versão Supabase)

Plataforma de venda de diamantes e passes **Free Fire** em Kwanzas: app Android (Java/XML, Android Studio), painel administrativo Web e base de dados **Supabase**.

## O que está aqui
| Pasta | Conteúdo |
|---|---|
| `android-app/` | App Android — abrir no **Android Studio** (Gradle 8.14.3, API 36) |
| `admin-web/` | Painel administrativo (site estático) |
| `supabase/` | Base de dados completa — **`INSTALL_ALL.sql`** instala tudo de uma vez |
| `documentation/` | Guias (instalação, CodeAssist, APK, painel, segurança, testes, Play Store) |
| `IMAGENS-DAS-TELAS/` | As 21 telas da app e capturas do painel |

## Já configurado
A app e o painel já estão ligados ao projecto Supabase **phgjhqwlphqhclbistpb**
(`SupabaseConfig.java` e `admin-web/js/config.js`), com a chave publicável `sb_publishable_…`.
Se esse projecto ainda não tiver a base de dados, faça os passos 2 a 5 e 8 abaixo **nesse projecto**
(o passo 6 já está feito).

## Começar — 8 passos
Guia completo: **`documentation/PASSO-A-PASSO-BASE-DE-DADOS.md`**
1. Criar um projecto Supabase **novo e vazio** (`ket-shop`).
2. SQL Editor → colar `supabase/INSTALL_ALL.sql` → **Run**.
3. Confirmar: `select count(*) from public.products;` → 13.
4. Authentication → Users → **Add user** (com *Auto Confirm User*).
5. Tornar-se admin (comando SQL no guia).
6. Copiar **Project URL** + chave **anon** para `admin-web/js/config.js` e `SupabaseConfig.java`.
7. Publicar o painel e entrar (`documentation/ADMIN_DEPLOYMENT.md`).
8. Painel → **Métodos de pagamento** → dados reais → activar.

Depois: abrir `android-app` no **Android Studio**, executar no telemóvel e gerar o AAB para a Play Store
(`documentation/ANDROID_STUDIO.md`).

## Publicar na Google Play
Ver **`documentation/PLAY-STORE.md`** — inclui o que ainda falta e a autorização da Garena para a marca Free Fire.

## Estado dos testes
- Base de dados: testada em PostgreSQL 16 com simulação do Supabase (fluxo completo, segurança entre clientes,
  reexecução sem erros, bloqueio automático em projectos de outra aplicação).
- Painel: 9 páginas sem erros em computador e telemóvel.
- App Android: compila sem erros contra o Android 16 (API 36); funções novas protegidas para Android 5+.
- **Não testado:** compilação completa pelo Gradle no Android Studio e execução num telemóvel real. As imagens da app são
  reconstruções fiéis a partir do projecto, não capturas de um telemóvel.
