# KET SHOP — Painel Admin (Firebase)

Painel administrativo da KET SHOP adaptado ao Firebase (Authentication, Cloud Firestore, Cloud Storage).

## Conteúdo
- `admin-web/` — o painel (HTML/CSS/JS). É só isto que se publica.
- `firebase/` — Security Rules (obrigatórias: colar na consola), índices e catálogo inicial.
- `documentation/` — guias de instalação, publicação e segurança.

## Pôr a funcionar (5 passos)
1. Consola Firebase: activar **Authentication → Email/Password**, **Firestore** e **Storage** (o Storage exige o plano Blaze).
2. Colar `firebase/firestore.rules` em Firestore → Regras e `firebase/storage.rules` em Storage → Regras → **Publicar**.
3. Criar a sua conta, copiar o UID e criar na consola o documento `roles/{UID}` com o campo `admin` (boolean) = `true`.
4. Colar o `firebaseConfig` da app Web do projecto em `admin-web/js/config.js`.
5. Publicar a pasta `admin-web` (Firebase Hosting, Netlify Drop, etc.), entrar em `login.html` e clicar em
   **Configurações → Carregar catálogo inicial**. Depois preencher os dados bancários em **Métodos de pagamento**.

Detalhes: `documentation/FIREBASE.md` e `documentation/ADMIN_DEPLOYMENT.md`.

## Páginas
Dashboard · Encomendas (tempo real, comprovativos, aprovar/rejeitar) · Produtos e preços · Clientes (papéis e bloqueio)
· Métodos de pagamento · Notificações · Relatórios (CSV) · Configurações · Auditoria.
